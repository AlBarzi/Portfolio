"""Export data from the existing WorldCup PostgreSQL DB to web/data/worldcup_snapshot.json."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import psycopg2


def fetchall(cur, query: str):
    cur.execute(query)
    return cur.fetchall()


def fetchone(cur, query: str):
    cur.execute(query)
    return cur.fetchone()


def main() -> None:
    parser = argparse.ArgumentParser(description="Export WorldCup snapshot for web build")
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=5432)
    parser.add_argument("--database", default="coupe_du_monde")
    parser.add_argument("--user", required=True)
    parser.add_argument("--password", required=True)
    args = parser.parse_args()

    conn = psycopg2.connect(
        host=args.host,
        port=args.port,
        dbname=args.database,
        user=args.user,
        password=args.password,
    )

    try:
        with conn.cursor() as cur:
            world_cups = [
                {
                    "year": row[0],
                    "host": row[1],
                    "champion": row[2] or "TBD",
                    "runner_up": row[3] or "TBD",
                }
                for row in fetchall(
                    cur,
                    """
                    SELECT
                        c.annee,
                        COALESCE(STRING_AGG(DISTINCT ph.pays, ' / ' ORDER BY ph.pays), 'TBD') AS host,
                        COALESCE(MAX(CASE WHEN pe.resultat_final = 'Vainqueur' THEN e.pays END), 'TBD') AS champion,
                        COALESCE(MAX(CASE WHEN pe.resultat_final = 'Finaliste' THEN e.pays END), 'TBD') AS runner_up
                    FROM coupe_du_monde c
                    LEFT JOIN pays_hote ph ON ph.id_coupe = c.id_coupe
                    LEFT JOIN participation_equipe pe ON pe.id_coupe = c.id_coupe
                    LEFT JOIN equipe e ON e.id_equipe = pe.id_equipe
                    GROUP BY c.id_coupe, c.annee
                    ORDER BY c.annee;
                    """,
                )
            ]

            teams = [
                {"name": row[0], "confederation": row[1], "titles": int(row[2])}
                for row in fetchall(
                    cur,
                    """
                    SELECT
                        e.pays,
                        e.confederation,
                        COALESCE(SUM(CASE WHEN pe.resultat_final = 'Vainqueur' THEN 1 ELSE 0 END), 0) AS titles
                    FROM equipe e
                    LEFT JOIN participation_equipe pe ON pe.id_equipe = e.id_equipe
                    GROUP BY e.id_equipe, e.pays, e.confederation
                    ORDER BY titles DESC, e.pays;
                    """,
                )
            ]

            players = [
                {"name": row[0], "nation": row[1] or "N/A", "position": row[2] or "N/A"}
                for row in fetchall(
                    cur,
                    """
                    SELECT CONCAT(j.prenom, ' ', j.nom) AS joueur, j.nationalite, j.poste
                    FROM joueur j
                    ORDER BY j.prenom, j.nom
                    LIMIT 500;
                    """,
                )
            ]

            top_scorers = [
                {"year": row[0], "name": row[1]}
                for row in fetchall(
                    cur,
                    """
                    WITH scorers AS (
                        SELECT
                            c.id_coupe,
                            c.annee,
                            CONCAT(j.prenom, ' ', j.nom) AS joueur,
                            SUM(pjm.buts) AS total_buts,
                            ROW_NUMBER() OVER (
                                PARTITION BY c.id_coupe
                                ORDER BY SUM(pjm.buts) DESC, CONCAT(j.prenom, ' ', j.nom)
                            ) AS rn
                        FROM participation_joueur_match pjm
                        JOIN match m ON m.id_match = pjm.id_match
                        JOIN coupe_du_monde c ON c.id_coupe = m.id_coupe
                        JOIN joueur j ON j.id_joueur = pjm.id_joueur
                        GROUP BY c.id_coupe, c.annee, j.id_joueur, j.prenom, j.nom
                    )
                    SELECT annee, joueur
                    FROM scorers
                    WHERE rn = 1
                    ORDER BY annee;
                    """,
                )
            ]

            matches_count_row = fetchone(cur, "SELECT COUNT(*) FROM match;")
            matches_count = int(matches_count_row[0]) if matches_count_row else 0

        payload = {
            "summary": {
                "editions": len(world_cups),
                "completed_editions": len([w for w in world_cups if w["champion"] != "TBD"]),
                "teams": len(teams),
                "players": len(players),
                "matches": matches_count,
            },
            "world_cups": world_cups,
            "teams": teams,
            "players": players,
            "stats": {
                "team_titles": teams[:12],
                "top_scorers": top_scorers,
            },
        }
    finally:
        conn.close()

    out = Path(__file__).parent / "data" / "worldcup_snapshot.json"
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Snapshot updated: {out}")


if __name__ == "__main__":
    main()

