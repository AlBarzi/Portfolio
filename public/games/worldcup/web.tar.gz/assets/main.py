"""Web runner for WorldCup using pygbag (Python -> WebAssembly).

This file lives inside the original WorldCup project, so no copy is created
under games/. It provides a Python-only web client for consultation.
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

import pygame

WIDTH = 1180
HEIGHT = 760
FPS = 60

BG = (10, 14, 22)
PANEL = (16, 24, 36)
TEXT = (225, 232, 245)
MUTED = (148, 165, 186)
ACCENT = (96, 197, 255)


def load_data() -> dict[str, Any]:
    path = Path(__file__).parent / "data" / "worldcup_snapshot.json"
    return json.loads(path.read_text(encoding="utf-8"))


def matches_query(item: dict[str, Any], keys: tuple[str, ...], query: str) -> bool:
    if not query:
        return True
    haystack = " ".join(str(item.get(k, "")).lower() for k in keys)
    return query in haystack


def draw_text(screen: pygame.Surface, font: pygame.font.Font, text: str, x: int, y: int, color: tuple[int, int, int]) -> None:
    screen.blit(font.render(text, True, color), (x, y))


async def main() -> None:
    pygame.init()
    pygame.display.set_caption("WorldCup - Python WASM (pygbag)")
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()

    title_font = pygame.font.SysFont("monospace", 34, bold=True)
    text_font = pygame.font.SysFont("monospace", 21)
    hint_font = pygame.font.SysFont("monospace", 17)

    payload = load_data()
    view = "summary"
    query = ""
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                break

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                    break
                if event.key == pygame.K_1:
                    view = "summary"
                elif event.key == pygame.K_2:
                    view = "cups"
                elif event.key == pygame.K_3:
                    view = "teams"
                elif event.key == pygame.K_4:
                    view = "players"
                elif event.key == pygame.K_5:
                    view = "stats"
                elif event.key == pygame.K_BACKSPACE:
                    query = query[:-1]
                elif event.key == pygame.K_DELETE:
                    query = ""
                elif event.unicode and len(event.unicode) == 1 and event.unicode.isprintable():
                    query += event.unicode

        screen.fill(BG)
        pygame.draw.rect(screen, PANEL, pygame.Rect(18, 18, WIDTH - 36, HEIGHT - 36), border_radius=14)

        draw_text(screen, title_font, "WorldCup Manager - Python WebAssembly", 38, 40, ACCENT)
        draw_text(screen, hint_font, "Views: [1] Summary [2] Cups [3] Teams [4] Players [5] Stats", 38, 86, MUTED)
        draw_text(screen, hint_font, "Search: type to filter teams/players, Backspace to edit, Delete to clear", 38, 108, MUTED)
        draw_text(screen, hint_font, "ESC to close", 38, 130, MUTED)
        draw_text(screen, text_font, f"Current: {view}", 38, 170, ACCENT)
        draw_text(screen, text_font, f"Query: {query or '(empty)'}", 38, 198, TEXT)

        lines: list[str] = []
        q = query.strip().lower()

        if view == "summary":
            s = payload.get("summary", {})
            lines = [
                f"Editions: {s.get('editions', 0)}",
                f"Completed editions: {s.get('completed_editions', 0)}",
                f"Teams: {s.get('teams', 0)}",
                f"Players: {s.get('players', 0)}",
                f"Matches: {s.get('matches', 0)}",
                "",
                "Data is loaded from a JSON snapshot exported from the SQL database.",
            ]
        elif view == "cups":
            lines.append("World Cups:")
            for row in payload.get("world_cups", []):
                lines.append(
                    f"{row.get('year')} | host={row.get('host')} | champion={row.get('champion')} | runner-up={row.get('runner_up')}"
                )
        elif view == "teams":
            teams = [
                t
                for t in payload.get("teams", [])
                if matches_query(t, ("name", "confederation"), q)
            ]
            lines.append(f"Teams ({len(teams)}):")
            for t in teams:
                lines.append(f"{t.get('name')} | confed={t.get('confederation')} | titles={t.get('titles')}")
        elif view == "players":
            players = [
                p
                for p in payload.get("players", [])
                if matches_query(p, ("name", "nation", "position"), q)
            ]
            lines.append(f"Players ({len(players)}):")
            for p in players:
                lines.append(f"{p.get('name')} | nation={p.get('nation')} | position={p.get('position')}")
        else:
            lines.append("Top teams by titles:")
            for row in payload.get("stats", {}).get("team_titles", []):
                lines.append(f"{row.get('team')} -> {row.get('titles')}")
            lines.append("")
            lines.append("Top scorers by edition:")
            for row in payload.get("stats", {}).get("top_scorers", []):
                lines.append(f"{row.get('year')} -> {row.get('name')}")

        y = 242
        for line in lines[:24]:
            draw_text(screen, text_font, line, 38, y, TEXT)
            y += 24

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())

