# WorldCup Web (Pygbag)

Ce dossier ajoute une cible web Python (WASM) dans le projet WorldCup existant.
Aucun clone du projet n'est cree dans `games/`.

## Important

- `tkinter` et `psycopg2` ne peuvent pas tourner directement dans le navigateur.
- La version web lit donc un snapshot JSON exporte depuis PostgreSQL.
- Le projet desktop original (`main.py`) reste intact.

## Installation

```bash
python3 -m pip install -r requirements-web.txt
```

## Mettre a jour les donnees web depuis la DB existante

```bash
python3 export_snapshot.py --user <postgres_user> --password <postgres_password>
```

## Build Pygbag

```bash
./build_web.sh
```

Artefact genere par Pygbag: `web/build/web/index.html`

Le script copie ensuite les fichiers vers `public/games/worldcup` pour que Vite les serve en statique.
Un patch post-build force aussi le chargement via `web.apk` (zip) pour eviter un blocage avec `web.tar.gz` servi avec `Content-Encoding: gzip` par Vite.

## Test local rapide

```bash
cd build/web
python3 -m http.server 8010
```

