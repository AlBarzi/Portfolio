#!/usr/bin/env zsh
set -euo pipefail

cd "$(dirname "$0")"
python3 -m pygbag --build --ume_block 0 main.py

repo_root="$(cd ../../../.. && pwd)"
target_dir="$repo_root/public/games/worldcup"

rm -rf "$target_dir"
mkdir -p "$target_dir"
cp -f build/web/* "$target_dir/"

# Vite sert *.gz avec Content-Encoding: gzip, ce qui casse la lecture Python en mode r:gz.
# On force la branche zip (web.apk), stable en dev et en prod.
python3 - <<'PY'
from pathlib import Path

paths = [
	Path("build/web/index.html"),
	Path("../../../../public/games/worldcup/index.html"),
]

needle = "if platform.window.location.host.find('.itch.zone')>0:"
replacement = "if True:"

for path in paths:
	if not path.exists():
		continue
	content = path.read_text(encoding="utf-8")
	if needle in content:
		path.write_text(content.replace(needle, replacement, 1), encoding="utf-8")
		print(f"Patched archive loader in {path}")
PY

echo "WorldCup web build copied to: $target_dir"

